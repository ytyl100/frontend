# Call Out Feature

A modern, interactive call out component built with jQuery and CSS that allows users to select icons and create rich text content.

## Features

### 🎯 Icon Selection
- Click the icon button (left side of call out header) to open the icon selection modal
- Choose from 20 pre-loaded Font Awesome icons including:
  - Info, Warning, Success, Error
  - Idea, Star, Heart, Bookmark
  - Bell, Calendar, Clock, Mail
  - Phone, Location, User, Settings
  - Download, Upload, Search, Home
- Search functionality to filter icons by name
- Selected icon appears in the call out header

### ✏️ Rich Text Editor
- Contenteditable text area with rich formatting support
- Formatting toolbar with the following options:
  - **Bold** (Ctrl+B)
  - *Italic* (Ctrl+I)
  - <u>Underline</u> (Ctrl+U)
  - Link creation
  - Bullet lists
  - Numbered lists
- Keyboard shortcuts for common formatting
- Auto-save functionality (saves to localStorage)
- Clean paste (removes unwanted formatting)

### 💾 Auto-Save & Persistence
- Content automatically saves to localStorage after 2 seconds of inactivity
- Saved content persists between browser sessions
- Manual save with Ctrl+S
- Visual notifications for save actions

## Files Structure

```
callout-feature/
├── index.html          # Main HTML structure
├── styles.css          # CSS styling and responsive design
├── script.js           # jQuery functionality and interactions
└── README.md           # This documentation file
```

## Usage

### Basic Setup
1. Include jQuery library (already included via CDN)
2. Include Font Awesome icons (already included via CDN)
3. Open `index.html` in a web browser

### Customization

#### Adding More Icons
To add more icons to the selection modal, edit the `#iconGrid` section in `index.html`:

```html
<div class="icon-item" data-icon="fas fa-your-icon">
    <i class="fas fa-your-icon"></i>
    <span>Your Label</span>
</div>
```

#### Styling Customization
Key CSS variables and classes you can modify in `styles.css`:

- `.callout-container` - Main call out styling
- `.callout-header` - Header background and colors
- `.icon-selector-btn` - Icon button styling
- `.rich-text-editor` - Text editor area
- `.modal-content` - Modal appearance
- `.icon-item` - Individual icon styling

#### JavaScript API
The component exposes utility functions via `window.calloutUtils`:

```javascript
// Get current content
const content = calloutUtils.getContent();
// Returns: { icon: "fas fa-check-circle", content: "<p>HTML content</p>", plainText: "Plain text" }

// Set content programmatically
calloutUtils.setContent("fas fa-star", "<p>New content</p>");

// Clear all content
calloutUtils.clearContent();

// Export as HTML
const html = calloutUtils.exportHTML();
```

## Browser Compatibility

- Modern browsers with ES6 support
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Dependencies

- jQuery 3.6.0 (loaded via CDN)
- Font Awesome 6.0.0 (loaded via CDN)

## Responsive Design

The component is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile devices

## Keyboard Shortcuts

- **Ctrl+B** - Bold formatting
- **Ctrl+I** - Italic formatting
- **Ctrl+U** - Underline formatting
- **Ctrl+S** - Manual save
- **Escape** - Close modal
- **Tab** - Insert 4 spaces in editor

## Technical Details

### CSS Features
- CSS Grid for icon layout
- Flexbox for responsive design
- CSS animations and transitions
- Custom scrollbars
- Backdrop blur effects
- Mobile-first responsive design

### JavaScript Features
- Event delegation for dynamic content
- Local storage for persistence
- Document.execCommand for rich text editing
- Custom notification system
- Search and filter functionality
- Keyboard shortcut handling

## License

This project is open source and available under the MIT License.

